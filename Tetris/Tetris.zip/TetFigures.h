#pragma once

#include <iostream>
#include <vector>
#include <time.h>

using namespace std;

#define FIGURE_WIDTH 4
#define FIGURE_HEIGHT 2

typedef int FIGURE_OBJECT[FIGURE_HEIGHT][FIGURE_WIDTH];


extern vector<FIGURE_OBJECT> TETRIS_FIGURES;
extern int TETRIS_CURRENT_FIGURE = 0;

int Tetris_SelectFigure();
void Tetris_InitializeFigures();