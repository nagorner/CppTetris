#include <stdio.h> 
#include <stdlib.h> 
#include "MatrixUtils.h"
#include "TetFigures.h"
int GAME_BOARD[ARRAY_SIZE][ARRAY_SIZE];

int CurrentFigure_RowPos=0;
int CurrentFigure_ColumnPos=0;
FIGURE_OBJECT *CurrentFigure;

void TetrisGame_Initialize()
{
	Matrix_FillbyValue(GAME_BOARD, 0);
}

void TetrisGame_Start()
{
	cout << "Starting the game";
}

void TetrisGame_Over()
{
	cout << "Game Over";
	exit(0);
}
void Tetris_AdditionToBoard() {
	Tetris_SelectFigure();

	CurrentFigure = &TETRIS_FIGURES[TETRIS_CURRENT_FIGURE];
	CurrentFigure_ColumnPos = ARRAY_SIZE / 2;
	bool result=Tetris_ApplyFigureToBoard(CurrentFigure_RowPos, CurrentFigure_ColumnPos, *CurrentFigure);
	if (!result)
		TetrisGame_Over();
}


bool Tetris_GameProcess_MoveFigureToDown()
{
	bool result;
	Tetris_DeleteFigureFromBoard(CurrentFigure_RowPos, CurrentFigure_ColumnPos, *CurrentFigure);
	CurrentFigure_RowPos++;
	result=Tetris_ApplyFigureToBoard(CurrentFigure_RowPos, CurrentFigure_ColumnPos, *CurrentFigure);
	return result;
}

void Tetris_DeleteFigureFromBoard(int rowNumber, int columnNumber, FIGURE_OBJECT whichFigure) {
	for (int i = 0; i < FIGURE_HEIGHT; i++) {
		for (int j = 0; j < FIGURE_WIDTH; j++) {

			GAME_BOARD[i + rowNumber][j + columnNumber] = 0;

		}
	}
}

bool Tetris_ApplyFigureToBoard(int rowNumber, int columnNumber, FIGURE_OBJECT whichFigure)
{

		for (int i = 0; i < FIGURE_HEIGHT; i++) {
			for (int j = 0; j < FIGURE_WIDTH; j++) {

				if (GAME_BOARD[i + rowNumber][j + columnNumber] == 1 && whichFigure[i][j] == 1) return false;

			}
		}
	for (int i = 0; i < FIGURE_HEIGHT; i++) {
		for (int j = 0; j < FIGURE_WIDTH; j++) {
			if (whichFigure[i][j] == 1)
			{
				GAME_BOARD[i + rowNumber][j + columnNumber] = whichFigure[i][j];
			}
		}
	}
	return true;
}

	