#include "pch.h"
#include <iostream>
#include <vector>
#include <time.h>
#include "TetFigures.h"


vector<FIGURE_OBJECT> TETRIS_FIGURES;

int TETRIS_CURRENT_FIGURE = 0;

int Tetris_SelectFigure()
{
	srand(time(NULL));
	TETRIS_CURRENT_FIGURE = rand() % 5;
}

void Tetris_InitializeFigures()
{
	FIGURE_OBJECT Figure1 =
	{
		{1,1,1,1},
		{0,0,0,0}
	};

	FIGURE_OBJECT Figure2 =
	{
		{ 1,1,1,0 },
		{0, 1, 0,0}
	};
	FIGURE_OBJECT Figure3 =
	{
		{0,1,1,0 },
		{0, 1,1,0 }
	};

	FIGURE_OBJECT Figure4 =
	{
		{ 1,1,0,0 },
		{ 0,1,1,0 }
	};
	FIGURE_OBJECT Figure5 = {
		{0, 1,1,1 },
		{0, 0,0,1 }
	};

	TETRIS_FIGURES.push_back(Figure1);
	TETRIS_FIGURES.push_back(Figure2);
	TETRIS_FIGURES.push_back(Figure3);
	TETRIS_FIGURES.push_back(Figure4);
	TETRIS_FIGURES.push_back(Figure5);


}



